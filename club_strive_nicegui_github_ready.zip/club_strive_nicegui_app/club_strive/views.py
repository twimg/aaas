from __future__ import annotations

import json
import tempfile
from pathlib import Path

from nicegui import ui, app

from .config import APP_NAME, COUNTRIES, DIV_COUNT, FORMATIONS, LIGHT_SENIORS, LIGHT_YOUTH, PLAYER_CLUB_SENIORS, PLAYER_CLUB_YOUTH, TACTIC_KEYS
from .logic import (
    buy_player, compute_wages, create_world, get_player, hire_coach,
    hire_manager, progress_week, rank_table, scout_visit, serialize_state,
    sign_scouted,
)
from .models import GameState, Player
from .persistence import load_state, save_state
from .storage import L, ensure_defaults, store
from .ui_helpers import notify_result, responsive_rows, stat_chip


def section_card(title: str):
    return ui.card().classes('w-full p-3 md:p-4 gap-3 rounded-2xl shadow-sm')


def render_setup() -> None:
    s = store()
    with ui.card().classes('w-full max-w-2xl mx-auto p-4 md:p-6 gap-4 rounded-2xl shadow-md'):
        ui.label(L('start_new')).classes('text-2xl md:text-3xl font-bold')
        ui.label('Mobile first, because giant desktop forms on a phone are miserable.').classes('text-sm text-gray-500')
        with ui.grid(columns=1).classes('w-full gap-3 md:grid-cols-2'):
            lang = ui.select({'ja': '日本語', 'en': 'English'}, value=s.get('lang', 'ja'), label=L('language')).classes('w-full')
            name_input = ui.input(label=L('player_name'), value=s.get('player_name', 'Player')).classes('w-full')
            country = ui.select(COUNTRIES, value='日本', label=L('country')).classes('w-full')
            division = ui.select({1: '1', 2: '2'}, value=1, label=L('division')).classes('w-full')
            difficulty = ui.select(['Easy', 'Normal', 'Hard'], value='Normal', label=L('difficulty')).classes('w-full')
            budget = ui.number(label=L('budget_mod'), value=1.0, min=0.7, max=1.5, step=0.05).classes('w-full')
        with ui.grid(columns=1).classes('w-full gap-2 sm:grid-cols-3'):
            stat_chip('World', f'{len(COUNTRIES)} countries')
            stat_chip('Divisions', str(DIV_COUNT))
            stat_chip('Squad', f'{PLAYER_CLUB_SENIORS}/{PLAYER_CLUB_YOUTH}')
        ui.label(f'Other squads: Seniors {LIGHT_SENIORS} / Youth {LIGHT_YOUTH}').classes('text-xs text-gray-500')

        def sync_lang() -> None:
            s['lang'] = lang.value
            s['player_name'] = name_input.value or 'Player'
            default_budget = {'Easy': 1.25, 'Normal': 1.0, 'Hard': 0.85}[difficulty.value]
            if abs(float(budget.value) - 1.0) < 1e-9:
                budget.value = default_budget

        lang.on('update:model-value', lambda _: sync_lang())
        difficulty.on('update:model-value', lambda _: sync_lang())

        def create() -> None:
            s['lang'] = lang.value
            s['player_name'] = name_input.value or 'Player'
            state = create_world(country.value, int(division.value), float(budget.value))
            save_state(state)
            ui.notify('World created.', color='positive')
            ui.navigate.reload()

        ui.button(L('create_world'), on_click=create).props('unelevated color=primary').classes('w-full h-12 rounded-xl')


def render_home(state: GameState) -> None:
    club = state.clubs[state.active_club_id]
    with section_card(L('home')):
        ui.label(L('home')).classes('text-xl md:text-2xl font-bold')
        with ui.grid(columns=1).classes('w-full gap-2 sm:grid-cols-2 xl:grid-cols-5'):
            stat_chip(L('season'), str(state.season))
            stat_chip(L('week'), str(state.week))
            stat_chip(L('club'), club.name)
            stat_chip(L('budget'), f'{club.budget:,}')
            stat_chip(L('wages'), f'{compute_wages(state, state.active_club_id):,}')

        ui.button(L('next_week'), on_click=lambda: (progress_week(state), save_state(state), ui.navigate.reload())).props('unelevated color=primary').classes('w-full md:w-auto h-11 rounded-xl')
        ui.label(L('match_log')).classes('text-lg font-medium mt-2')
        rows = []
        for row in reversed(state.match_log[-20:]):
            rows.append({
                'Season': row['season'],
                'Week': row['week'],
                'Match': f"{state.clubs[row['home']].name} {row['hg']} - {row['ag']} {state.clubs[row['away']].name}",
                'Div': row['div'],
                'Country': row['country'],
            })
        responsive_rows(rows, ['Season', 'Week', 'Match', 'Div', 'Country'], title_key='Match', subtitle_keys=['Country', 'Div'], detail_keys=['Season', 'Week'], pagination=8, max_mobile_items=12) if rows else ui.label('No matches yet.')


def render_table(state: GameState) -> None:
    with section_card(L('table')):
        ui.label(L('table')).classes('text-xl md:text-2xl font-bold')
        with ui.grid(columns=1).classes('w-full gap-3 md:grid-cols-[1fr_auto]'):
            country = ui.select(COUNTRIES, value=state.active_country, label='Country').classes('w-full')
            division = ui.select({1: '1', 2: '2'}, value=state.active_division, label='Division').classes('w-full md:w-32')
        container = ui.column().classes('w-full')

        def redraw() -> None:
            container.clear()
            league = state.leagues[country.value]
            table = league['table1'] if int(division.value) == 1 else league['table2']
            ranked = rank_table(table)
            rows = []
            for i, tid in enumerate(ranked, start=1):
                r = table[tid]
                rows.append({'#': i, 'Club': state.clubs[tid].name, 'Pts': r['pts'], 'W': r['w'], 'D': r['d'], 'L': r['l'], 'GF': r['gf'], 'GA': r['ga'], 'GD': r['gf'] - r['ga']})
            with container:
                responsive_rows(rows, ['#', 'Club', 'Pts', 'W', 'D', 'L', 'GF', 'GA', 'GD'], title_key='Club', subtitle_keys=['#'], detail_keys=['Pts', 'W', 'D', 'L', 'GD'], pagination=10, max_mobile_items=20)

        country.on('update:model-value', lambda _: redraw())
        division.on('update:model-value', lambda _: redraw())
        redraw()


def render_squad(state: GameState) -> None:
    cid = state.active_club_id
    players = [p for p in state.players if p.club_id == cid]
    seniors = [p for p in players if not p.is_youth]
    youths = [p for p in players if p.is_youth]
    with section_card(L('squad')):
        ui.label(L('squad')).classes('text-xl md:text-2xl font-bold')
        with ui.grid(columns=1).classes('w-full gap-2 sm:grid-cols-2'):
            stat_chip('Seniors', str(len(seniors)))
            stat_chip('Youth', str(len(youths)))

        def rows_from(ps: list[Player]) -> list[dict]:
            return [{'PID': p.pid, 'Name': p.name, 'Pos': p.pos, 'Age': p.age, 'Nat': p.nationality, 'OVR': p.overall, 'POT': p.pot, 'Inj': p.injury_weeks} for p in sorted(ps, key=lambda x: x.overall, reverse=True)]

        ui.label('Seniors').classes('text-lg font-medium')
        responsive_rows(rows_from(seniors), ['PID', 'Name', 'Pos', 'Age', 'Nat', 'OVR', 'POT', 'Inj'], title_key='Name', subtitle_keys=['Pos', 'Nat'], detail_keys=['Age', 'OVR', 'POT', 'Inj'], pagination=8, max_mobile_items=30)
        ui.label('Youth').classes('text-lg font-medium mt-2')
        responsive_rows(rows_from(youths), ['PID', 'Name', 'Pos', 'Age', 'Nat', 'OVR', 'POT', 'Inj'], title_key='Name', subtitle_keys=['Pos', 'Nat'], detail_keys=['Age', 'OVR', 'POT', 'Inj'], pagination=8, max_mobile_items=20)


def render_tactics(state: GameState) -> None:
    club = state.clubs[state.active_club_id]
    with section_card(L('tactics')):
        ui.label(L('tactics')).classes('text-xl md:text-2xl font-bold')
        with ui.grid(columns=1).classes('w-full gap-3 md:grid-cols-2'):
            formation = ui.select(FORMATIONS, value=club.formation, label='Formation').classes('w-full')
            tactic = ui.select(TACTIC_KEYS, value=club.tactic, label='Tactic').classes('w-full')

        def save_tactic() -> None:
            club.formation = formation.value
            club.tactic = tactic.value
            save_state(state)
            ui.notify('Tactics updated.', color='positive')

        ui.button('Apply', on_click=save_tactic).props('unelevated color=primary').classes('w-full md:w-auto h-11 rounded-xl')
        manager = state.managers.get(club.manager_id)
        if manager:
            with ui.card().classes('w-full p-3 rounded-xl bg-slate-50 shadow-none'):
                ui.label('Manager fit').classes('text-sm font-medium')
                ui.label(f'{manager.name} | Pref: {manager.preferred_formation} / {manager.preferred_tactic}').classes('text-sm text-gray-600')


def render_transfers(state: GameState) -> None:
    club = state.clubs[state.active_club_id]
    with section_card(L('transfers')):
        ui.label(L('transfers')).classes('text-xl md:text-2xl font-bold')
        stat_chip(L('budget'), f'{club.budget:,}')
        rows = []
        for pid in state.transfer_market[:120]:
            p = get_player(state, pid)
            if not p:
                continue
            src = state.clubs.get(p.club_id).name if p.club_id in state.clubs else '-'
            price = int((p.overall ** 2) * 1200)
            rows.append({'PID': p.pid, 'Name': p.name, 'Pos': p.pos, 'Age': p.age, 'Nat': p.nationality, 'OVR': p.overall, 'POT': p.pot, 'From': src, 'EstPrice': price})
        responsive_rows(rows, ['PID', 'Name', 'Pos', 'Age', 'Nat', 'OVR', 'POT', 'From', 'EstPrice'], title_key='Name', subtitle_keys=['Pos', 'From'], detail_keys=['Age', 'OVR', 'POT', 'EstPrice'], pagination=10, max_mobile_items=30)
        with ui.grid(columns=1).classes('w-full gap-3 md:grid-cols-[140px_auto] items-end'):
            pid_input = ui.number(label='PID', value=1, min=1).classes('w-full')
            ui.button(L('buy'), on_click=lambda: (lambda ok_msg=buy_player(state, int(pid_input.value or 1)): (save_state(state), notify_result(*ok_msg), ui.navigate.reload()))()).props('unelevated color=primary').classes('w-full md:w-auto h-11 rounded-xl')


def render_scouting(state: GameState) -> None:
    club = state.clubs[state.active_club_id]
    with section_card(L('scouting')):
        ui.label(L('scouting')).classes('text-xl md:text-2xl font-bold')
        stat_chip(L('budget'), f'{club.budget:,}')
        rows = []
        for pid in state.scout_market[:120]:
            p = get_player(state, pid)
            if not p:
                continue
            rows.append({'PID': p.pid, 'Name': p.name, 'Pos': p.pos, 'Age': p.age, 'Nat': p.nationality, 'Scouted': p.scouted_level, 'EstOVR': p.est_overall if p.scouted_level > 0 else '-', 'EstPOT': p.est_pot if p.scouted_level > 0 else '-'})
        responsive_rows(rows, ['PID', 'Name', 'Pos', 'Age', 'Nat', 'Scouted', 'EstOVR', 'EstPOT'], title_key='Name', subtitle_keys=['Pos', 'Nat'], detail_keys=['Age', 'Scouted', 'EstOVR', 'EstPOT'], pagination=10, max_mobile_items=30)
        pid_input = ui.number(label='Scout PID', value=1, min=1).classes('w-full md:w-40')
        with ui.grid(columns=1).classes('w-full gap-2 md:grid-cols-3 items-end'):
            pid_input
            ui.button(L('visit'), on_click=lambda: (lambda ok_msg=scout_visit(state, int(pid_input.value or 1)): (save_state(state), notify_result(*ok_msg), ui.navigate.reload()))()).props('outline').classes('w-full h-11 rounded-xl')
            ui.button(L('sign'), on_click=lambda: (lambda ok_msg=sign_scouted(state, int(pid_input.value or 1)): (save_state(state), notify_result(*ok_msg), ui.navigate.reload()))()).props('unelevated color=primary').classes('w-full h-11 rounded-xl')


def render_staff(state: GameState) -> None:
    club = state.clubs[state.active_club_id]
    with section_card(L('staff')):
        ui.label(L('staff')).classes('text-xl md:text-2xl font-bold')
        manager = state.managers.get(club.manager_id)
        with ui.card().classes('w-full p-3 rounded-xl bg-slate-50 shadow-none gap-1'):
            ui.label('Current Manager').classes('text-base font-medium')
            ui.label(f"{manager.name} ({manager.nationality}) age {manager.age} | tac {manager.tactical} man {manager.man_mgmt} tr {manager.transfer_skill}" if manager else 'None').classes('text-sm text-gray-600')
        with ui.card().classes('w-full p-3 rounded-xl bg-slate-50 shadow-none gap-1'):
            ui.label('Coaches').classes('text-base font-medium')

            def coach_line(coach_id: int | None, label: str) -> str:
                if coach_id and coach_id in state.coaches:
                    c = state.coaches[coach_id]
                    return f'{label}: {c.name} ({c.role}) tac {c.tactical} fit {c.fitness} youth {c.youth}'
                return f'{label}: None'

            ui.label(coach_line(club.coach_assist, 'Assist')).classes('text-sm text-gray-600')
            ui.label(coach_line(club.coach_fitness, 'Fitness')).classes('text-sm text-gray-600')
            ui.label(coach_line(club.coach_youth, 'Youth')).classes('text-sm text-gray-600')

        ui.separator()
        ui.label('Hire Manager').classes('text-lg font-medium')
        mgr_rows = []
        for mid in state.staff_market_managers[:60]:
            mm = state.managers.get(mid)
            if mm:
                mgr_rows.append({'MID': mm.mid, 'Name': mm.name, 'Nat': mm.nationality, 'Age': mm.age, 'PrefTac': mm.preferred_tactic, 'PrefForm': mm.preferred_formation, 'Tac': mm.tactical, 'Man': mm.man_mgmt, 'Youth': mm.youth_dev, 'Wage': mm.wage})
        responsive_rows(mgr_rows, ['MID', 'Name', 'Nat', 'Age', 'PrefTac', 'PrefForm', 'Tac', 'Man', 'Youth', 'Wage'], title_key='Name', subtitle_keys=['Nat', 'PrefTac'], detail_keys=['Age', 'Tac', 'Man', 'Youth', 'Wage'], pagination=8, max_mobile_items=20)
        with ui.grid(columns=1).classes('w-full gap-2 md:grid-cols-[140px_auto] items-end'):
            mid_input = ui.number(label='MID', value=1, min=1).classes('w-full')
            ui.button(L('hire'), on_click=lambda: (lambda ok_msg=hire_manager(state, int(mid_input.value or 1)): (save_state(state), notify_result(*ok_msg), ui.navigate.reload()))()).props('unelevated color=primary').classes('w-full md:w-auto h-11 rounded-xl')

        ui.separator()
        ui.label('Hire Coach').classes('text-lg font-medium')
        coach_rows = []
        for coach_id in state.staff_market_coaches[:60]:
            cc = state.coaches.get(coach_id)
            if cc:
                coach_rows.append({'CID': cc.cid, 'Name': cc.name, 'Role': cc.role, 'Nat': cc.nationality, 'Age': cc.age, 'Tac': cc.tactical, 'Fit': cc.fitness, 'Youth': cc.youth, 'Wage': cc.wage})
        responsive_rows(coach_rows, ['CID', 'Name', 'Role', 'Nat', 'Age', 'Tac', 'Fit', 'Youth', 'Wage'], title_key='Name', subtitle_keys=['Role', 'Nat'], detail_keys=['Age', 'Tac', 'Fit', 'Youth', 'Wage'], pagination=8, max_mobile_items=20)
        with ui.grid(columns=1).classes('w-full gap-2 md:grid-cols-[140px_auto] items-end'):
            cid_input = ui.number(label='CID', value=1, min=1).classes('w-full')
            ui.button(L('hire'), on_click=lambda: (lambda ok_msg=hire_coach(state, int(cid_input.value or 1)): (save_state(state), notify_result(*ok_msg), ui.navigate.reload()))()).props('unelevated color=primary').classes('w-full md:w-auto h-11 rounded-xl')


def render_save_load(state: GameState) -> None:
    with section_card(L('save_load')):
        ui.label(L('save_load')).classes('text-xl md:text-2xl font-bold')

        def download() -> None:
            blob = json.dumps(serialize_state(state), ensure_ascii=False, indent=2)
            tmp = Path(tempfile.gettempdir()) / 'club_strive_save.json'
            tmp.write_text(blob, encoding='utf-8')
            ui.download(str(tmp))

        ui.button(L('download_save'), on_click=download).props('unelevated color=primary').classes('w-full md:w-auto h-11 rounded-xl')

        def on_upload(event) -> None:
            try:
                content = event.content.read().decode('utf-8')
                loaded = __import__('club_strive.logic', fromlist=['deserialize_state']).deserialize_state(json.loads(content))
                save_state(loaded)
                ui.notify('Loaded.', color='positive')
                ui.navigate.reload()
            except Exception as ex:
                ui.notify(f'Load failed: {ex}', color='negative')

        ui.upload(on_upload=on_upload, auto_upload=True, label=L('upload_save')).props('accept=.json').classes('w-full')


def render_app(state: GameState) -> None:
    club = state.clubs[state.active_club_id]
    nav_options = {
        'home': L('home'),
        'table': L('table'),
        'squad': L('squad'),
        'tactics': L('tactics'),
        'transfers': L('transfers'),
        'scouting': L('scouting'),
        'staff': L('staff'),
        'save': L('save_load'),
    }
    current_section = app.storage.user.get('section', 'home')

    def render_current() -> None:
        content.clear()
        with content:
            if section_select.value == 'home':
                render_home(state)
            elif section_select.value == 'table':
                render_table(state)
            elif section_select.value == 'squad':
                render_squad(state)
            elif section_select.value == 'tactics':
                render_tactics(state)
            elif section_select.value == 'transfers':
                render_transfers(state)
            elif section_select.value == 'scouting':
                render_scouting(state)
            elif section_select.value == 'staff':
                render_staff(state)
            elif section_select.value == 'save':
                render_save_load(state)

    with ui.column().classes('w-full max-w-7xl mx-auto gap-4 pb-24 md:pb-6'):
        with ui.card().classes('w-full p-4 rounded-2xl shadow-md gap-3'):
            with ui.row().classes('w-full items-center justify-between gap-3 flex-wrap'):
                with ui.column().classes('gap-0'):
                    ui.label(APP_NAME).classes('text-xl md:text-2xl font-bold')
                    ui.label(f"{club.name} • {state.active_country} D{club.division}").classes('text-sm text-gray-500')
                lang = ui.select({'ja': '日本語', 'en': 'English'}, value=store().get('lang', 'ja'), label=L('language')).classes('w-full sm:w-40')
                lang.on('update:model-value', lambda _: (store().__setitem__('lang', lang.value), ui.navigate.reload()))
            with ui.grid(columns=1).classes('w-full gap-2 sm:grid-cols-3 lg:grid-cols-5'):
                stat_chip(L('season'), str(state.season))
                stat_chip(L('week'), str(state.week))
                stat_chip(L('club'), club.name)
                stat_chip(L('budget'), f'{club.budget:,}')
                stat_chip(L('wages'), f'{compute_wages(state, state.active_club_id):,}')
            with ui.grid(columns=1).classes('w-full gap-3 md:grid-cols-[1fr_auto] items-end'):
                section_select = ui.select(nav_options, value=current_section, label='Section').classes('w-full')

                def reset() -> None:
                    save_state(None)
                    ui.navigate.reload()

                ui.button(L('start_new'), on_click=reset).props('outline').classes('w-full md:w-auto h-11 rounded-xl')
            section_select.on('update:model-value', lambda _: (app.storage.user.__setitem__('section', section_select.value), render_current()))

        content = ui.column().classes('w-full gap-4')
        render_current()

        with ui.footer(value=False).classes('md:hidden bg-white/95 backdrop-blur border-t border-slate-200'):
            with ui.row().classes('w-full justify-around items-center px-2 py-2 gap-1'):
                for key in ['home', 'table', 'squad', 'transfers', 'save']:
                    ui.button(nav_options[key], on_click=lambda k=key: (setattr(section_select, 'value', k), app.storage.user.__setitem__('section', k), render_current())).props('flat size=sm').classes('text-xs min-w-0 flex-1')


def build_index() -> None:
    ensure_defaults()
    ui.page_title(APP_NAME)
    ui.add_head_html('''
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <style>
      body { background: #f8fafc; }
      .nicegui-content { max-width: 100vw; overflow-x: hidden; }
      .q-table tbody td { white-space: normal !important; }
      .q-card { border-radius: 1rem; }
    </style>
    ''')
    state = load_state()
    with ui.column().classes('w-full p-3 md:p-4'):
        if state is None:
            render_setup()
        else:
            render_app(state)
