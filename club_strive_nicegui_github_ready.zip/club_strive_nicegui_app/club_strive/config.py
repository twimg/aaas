from __future__ import annotations

APP_NAME = "Club Strive"
RNG_SEED = 42

COUNTRIES = [
    "日本", "ブラジル", "ドイツ", "フランス", "イタリア", "スペイン", "イングランド",
    "ベルギー", "クロアチア", "ポルトガル", "アメリカ", "メキシコ", "カナダ",
    "スイス", "トルコ", "セルビア", "エジプト", "ガーナ", "中国", "サウジアラビア", "オーストラリア"
]

TEAMS_PER_DIV = 10
DIV_COUNT = 2
WEEKS_PER_SEASON = (TEAMS_PER_DIV - 1) * 2

PLAYER_CLUB_SENIORS = 40
PLAYER_CLUB_YOUTH = 24
OTHER_CLUB_SENIORS = 24
OTHER_CLUB_YOUTH = 24
LIGHT_SENIORS = 12
LIGHT_YOUTH = 12

BASE_ATTENDANCE = 18000
TICKET_PRICE = 28
SPONSOR_WEEKLY = 450_000
WAGE_MULT = 1200
YOUTH_WAGE_RATE = 0.75

TRANSFER_WINDOW_WEEKS = {1, 10}
TRANSFER_MARKET_SIZE = 80
SCOUT_POOL_SIZE = 80
STAFF_POOL_SIZE = 40

ATTRS = ["SPD", "PAS", "TEC", "DEF", "PHY", "SHT", "MEN"]
TACTIC_PRESETS = {
    "BAL": {"atk": 1.00, "def": 1.00, "mid": 1.00, "var": 1.00, "fatigue": 1.00},
    "POS": {"atk": 1.03, "def": 1.00, "mid": 1.08, "var": 0.95, "fatigue": 1.05},
    "CNT": {"atk": 1.06, "def": 0.98, "mid": 0.98, "var": 1.10, "fatigue": 1.00},
    "PRS": {"atk": 1.05, "def": 1.03, "mid": 1.02, "var": 1.05, "fatigue": 1.12},
    "LBL": {"atk": 0.96, "def": 1.10, "mid": 0.95, "var": 0.90, "fatigue": 0.96},
    "WNG": {"atk": 1.07, "def": 0.97, "mid": 1.00, "var": 1.08, "fatigue": 1.03},
}
TACTIC_KEYS = list(TACTIC_PRESETS.keys())
FORMATIONS = ["442", "433", "4231", "352", "451", "343", "4141", "541", "532", "424"]
POS_GROUPS = ["GK", "DF", "MF", "FW"]

I18N = {
    "title": {"ja": APP_NAME, "en": APP_NAME},
    "language": {"ja": "言語", "en": "Language"},
    "start_new": {"ja": "新規開始", "en": "New Game"},
    "player_name": {"ja": "プレイヤー名（表示）", "en": "Player Name"},
    "country": {"ja": "開始国（リーグ）", "en": "Starting Country (League)"},
    "division": {"ja": "ディビジョン", "en": "Division"},
    "difficulty": {"ja": "難易度", "en": "Difficulty"},
    "budget_mod": {"ja": "初期資金補正", "en": "Starting Budget Modifier"},
    "create_world": {"ja": "ワールド生成", "en": "Create World"},
    "creating": {"ja": "ワールド生成中…", "en": "Creating world..."},
    "home": {"ja": "ホーム", "en": "Home"},
    "table": {"ja": "順位表", "en": "Table"},
    "squad": {"ja": "選手", "en": "Squad"},
    "tactics": {"ja": "戦術", "en": "Tactics"},
    "transfers": {"ja": "移籍", "en": "Transfers"},
    "scouting": {"ja": "スカウト", "en": "Scouting"},
    "staff": {"ja": "スタッフ", "en": "Staff"},
    "save_load": {"ja": "セーブ/ロード", "en": "Save/Load"},
    "next_week": {"ja": "次の週へ ▶", "en": "Next Week ▶"},
    "season": {"ja": "シーズン", "en": "Season"},
    "week": {"ja": "週", "en": "Week"},
    "club": {"ja": "クラブ", "en": "Club"},
    "budget": {"ja": "予算", "en": "Budget"},
    "wages": {"ja": "週給合計", "en": "Weekly Wages"},
    "match_log": {"ja": "試合ログ", "en": "Match Log"},
    "save": {"ja": "セーブ", "en": "Save"},
    "load": {"ja": "ロード", "en": "Load"},
    "download_save": {"ja": "セーブデータをダウンロード", "en": "Download save"},
    "upload_save": {"ja": "セーブデータをアップロード", "en": "Upload save"},
    "buy": {"ja": "獲得", "en": "Buy"},
    "visit": {"ja": "視察", "en": "Scout Visit"},
    "sign": {"ja": "契約", "en": "Sign"},
    "hire": {"ja": "雇用", "en": "Hire"},
}

NAME_BANK = {
    "日本": (["佐藤", "鈴木", "高橋", "田中", "伊藤", "山本", "渡辺", "中村", "小林", "加藤"],
            ["翔太", "蓮", "悠真", "蒼", "大輝", "陽斗", "颯太", "健太", "拓海", "海斗"]),
    "ブラジル": (["Silva", "Santos", "Oliveira", "Souza", "Costa", "Pereira", "Rodrigues", "Almeida", "Gomes", "Carvalho"],
                ["Lucas", "Mateus", "Gabriel", "Rafael", "Bruno", "Pedro", "Joao", "Diego", "Thiago", "Felipe"]),
    "ドイツ": (["Muller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner", "Becker", "Hoffmann", "Koch"],
              ["Lukas", "Jonas", "Leon", "Finn", "Noah", "Paul", "Felix", "Max", "Tim", "Moritz"]),
    "フランス": (["Martin", "Bernard", "Dubois", "Thomas", "Robert", "Richard", "Petit", "Durand", "Leroy", "Moreau"],
                ["Hugo", "Louis", "Lucas", "Nathan", "Enzo", "Theo", "Jules", "Arthur", "Leo", "Adam"]),
    "イタリア": (["Rossi", "Russo", "Ferrari", "Esposito", "Bianchi", "Romano", "Gallo", "Costa", "Fontana", "Conti"],
                ["Luca", "Marco", "Matteo", "Andrea", "Giuseppe", "Federico", "Antonio", "Giorgio", "Stefano", "Davide"]),
    "スペイン": (["Garcia", "Fernandez", "Gonzalez", "Rodriguez", "Lopez", "Martinez", "Sanchez", "Perez", "Gomez", "Martin"],
                ["Hugo", "Daniel", "Pablo", "Alejandro", "Adrian", "Alvaro", "Diego", "Ivan", "Javier", "Sergio"]),
    "イングランド": (["Smith", "Jones", "Taylor", "Brown", "Williams", "Wilson", "Johnson", "Davies", "Robinson", "Wright"],
                    ["Jack", "Harry", "Charlie", "Thomas", "George", "James", "Oliver", "Joshua", "Noah", "Leo"]),
}
DEFAULT_SUR = ["Kim", "Nguyen", "Ali", "Khan", "Singh", "Haddad", "Ivanov", "Popov", "Hassan", "Mensah"]
DEFAULT_GIV = ["Alex", "Sam", "Milan", "Omar", "Yusuf", "Niko", "Rami", "Noel", "Kai", "Eli"]
