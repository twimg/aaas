from __future__ import annotations

import json
import math
import random
from dataclasses import asdict
from typing import Any, Dict, List, Optional, Tuple

from .config import (
    ATTRS, COUNTRIES, DEFAULT_GIV, DEFAULT_SUR, FORMATIONS, LIGHT_SENIORS,
    LIGHT_YOUTH, NAME_BANK, OTHER_CLUB_SENIORS, OTHER_CLUB_YOUTH,
    PLAYER_CLUB_SENIORS, PLAYER_CLUB_YOUTH, POS_GROUPS, RNG_SEED,
    SCOUT_POOL_SIZE, SPONSOR_WEEKLY, STAFF_POOL_SIZE, TACTIC_KEYS,
    TACTIC_PRESETS, TEAMS_PER_DIV, TRANSFER_MARKET_SIZE,
    TRANSFER_WINDOW_WEEKS, WAGE_MULT, WEEKS_PER_SEASON, YOUTH_WAGE_RATE,
)
from .models import Club, Coach, GameState, Manager, Player
from .storage import store


def clamp(x: int, lo: int, hi: int) -> int:
    return lo if x < lo else hi if x > hi else x


def unique_name(rng: random.Random, country: str, used: set) -> str:
    sur, giv = NAME_BANK.get(country, (DEFAULT_SUR, DEFAULT_GIV))
    for _ in range(2000):
        name = f"{rng.choice(sur)} {rng.choice(giv)}"
        if name not in used:
            used.add(name)
            return name
    name = f"{rng.choice(sur)} {rng.choice(giv)} {rng.randint(1, 9999)}"
    used.add(name)
    return name


def _rng() -> random.Random:
    return random.Random(RNG_SEED + int(store().get("tick", 0)))


def gen_attrs(rng: random.Random, base: int, spread: int) -> Dict[str, int]:
    return {a: clamp(int(rng.gauss(base, spread)), 25, 99) for a in ATTRS}


def gen_player(rng: random.Random, state: GameState, club_id: str, country: str, is_youth: bool) -> Player:
    pid = state.next_pid
    state.next_pid += 1
    pos = rng.choices(POS_GROUPS, weights=[1, 4, 4, 2])[0]
    age = rng.randint(14, 18) if is_youth else rng.randint(18, 33)
    base = 48 if is_youth else 54 + (state.clubs[club_id].reputation if club_id in state.clubs else 50) // 8
    attrs = gen_attrs(rng, base, 9 if pos == "GK" else 8)
    if pos == "GK":
        attrs["DEF"] = clamp(attrs["DEF"] + rng.randint(6, 12), 25, 99)
        attrs["MEN"] = clamp(attrs["MEN"] + rng.randint(3, 8), 25, 99)
    elif pos == "DF":
        attrs["DEF"] = clamp(attrs["DEF"] + rng.randint(8, 14), 25, 99)
        attrs["PHY"] = clamp(attrs["PHY"] + rng.randint(5, 10), 25, 99)
    elif pos == "MF":
        attrs["PAS"] = clamp(attrs["PAS"] + rng.randint(7, 13), 25, 99)
        attrs["TEC"] = clamp(attrs["TEC"] + rng.randint(5, 11), 25, 99)
    else:
        attrs["SHT"] = clamp(attrs["SHT"] + rng.randint(7, 13), 25, 99)
        attrs["SPD"] = clamp(attrs["SPD"] + rng.randint(5, 10), 25, 99)
    pot = clamp((sum(attrs.values()) // len(attrs)) + rng.randint(8, 24), 45, 95)
    return Player(
        pid=pid,
        name=unique_name(rng, country, store().setdefault("used_names", set())),
        age=age,
        nationality=country,
        pos=pos,
        club_id=club_id,
        is_youth=is_youth,
        retire_age=rng.randint(34, 39),
        attrs=attrs,
        pot=pot,
        morale=clamp(int(rng.gauss(60, 12)), 30, 90),
        stamina=clamp(int(rng.gauss(88, 8)), 50, 100),
    )


def gen_manager(rng: random.Random, state: GameState, country: str) -> Manager:
    mid = state.next_mid
    state.next_mid += 1
    return Manager(
        mid=mid,
        name=unique_name(rng, country, store().setdefault("used_names", set())),
        age=rng.randint(35, 67),
        nationality=country,
        retire_age=rng.randint(60, 72),
        preferred_tactic=rng.choice(TACTIC_KEYS),
        preferred_formation=rng.choice(FORMATIONS),
        tactical=rng.randint(45, 90),
        man_mgmt=rng.randint(45, 90),
        youth_dev=rng.randint(40, 90),
        transfer_skill=rng.randint(40, 90),
        discipline=rng.randint(45, 90),
        wage=rng.randint(120_000, 520_000),
        contract_years=rng.randint(1, 4),
    )


def gen_coach(rng: random.Random, state: GameState, country: str) -> Coach:
    cid = state.next_cid
    state.next_cid += 1
    role = rng.choice(["ASSIST", "FITNESS", "YOUTH"])
    return Coach(
        cid=cid,
        name=unique_name(rng, country, store().setdefault("used_names", set())),
        age=rng.randint(28, 64),
        nationality=country,
        role=role,
        tactical=rng.randint(40, 90),
        fitness=rng.randint(40, 90),
        youth=rng.randint(40, 90),
        wage=rng.randint(70_000, 220_000),
        contract_years=rng.randint(1, 4),
    )


def club_id(country: str, division: int, idx: int) -> str:
    return f"{country}_D{division}_{idx:02d}"


def create_fixtures(team_ids: List[str], rng: random.Random) -> List[List[Tuple[str, str]]]:
    teams = team_ids[:]
    if len(teams) % 2 == 1:
        teams.append("BYE")
    n = len(teams)
    rounds: List[List[Tuple[str, str]]] = []
    for _ in range(n - 1):
        pairings = []
        for i in range(n // 2):
            t1, t2 = teams[i], teams[n - 1 - i]
            if t1 != "BYE" and t2 != "BYE":
                pairings.append((t1, t2))
        rounds.append(pairings)
        teams = [teams[0], teams[-1], *teams[1:-1]]
    second = [[(b, a) for (a, b) in rnd] for rnd in rounds]
    all_rounds = rounds + second
    rng.shuffle(all_rounds)
    return all_rounds[:WEEKS_PER_SEASON]


def init_table(team_ids: List[str]) -> Dict[str, Dict[str, int]]:
    return {tid: {"pts": 0, "w": 0, "d": 0, "l": 0, "gf": 0, "ga": 0} for tid in team_ids}


def compute_wages(state: GameState, cid: str) -> int:
    total = 0
    for p in state.players:
        if p.club_id == cid:
            base = p.overall * WAGE_MULT
            if p.is_youth:
                base = int(base * YOUTH_WAGE_RATE)
            total += base
    club = state.clubs[cid]
    if club.manager_id in state.managers:
        total += state.managers[club.manager_id].wage
    for coach_id in [club.coach_assist, club.coach_fitness, club.coach_youth]:
        if coach_id and coach_id in state.coaches:
            total += state.coaches[coach_id].wage
    return total


def create_world(active_country: str, active_division: int, budget_mod: float = 1.0) -> GameState:
    rng = _rng()
    store()["used_names"] = set()
    state = GameState(active_country=active_country, active_division=active_division)
    for ctry in COUNTRIES:
        d1_ids, d2_ids = [], []
        for div in [1, 2]:
            for idx in range(1, TEAMS_PER_DIV + 1):
                cid = club_id(ctry, div, idx)
                mgr = gen_manager(rng, state, ctry)
                state.managers[mgr.mid] = mgr
                rep = int(58 - (div - 1) * 6 + rng.randint(-7, 7))
                budget = int((26_000_000 + rep * 240_000 + rng.randint(-3_000_000, 3_000_000)) * (budget_mod if ctry == active_country and div == active_division and idx == 1 else 1.0))
                club = Club(
                    club_id=cid,
                    name=f"{ctry} Club {div}-{idx}",
                    country=ctry,
                    division=div,
                    budget=budget,
                    reputation=rep,
                    manager_id=mgr.mid,
                    tactic=mgr.preferred_tactic,
                    formation=mgr.preferred_formation,
                )
                state.clubs[cid] = club
                (d1_ids if div == 1 else d2_ids).append(cid)
        state.leagues[ctry] = {
            "div1_ids": d1_ids,
            "div2_ids": d2_ids,
            "fix1": create_fixtures(d1_ids, rng),
            "fix2": create_fixtures(d2_ids, rng),
            "table1": init_table(d1_ids),
            "table2": init_table(d2_ids),
        }
    state.active_club_id = club_id(active_country, active_division, 1)
    for cid, club in state.clubs.items():
        is_player = cid == state.active_club_id
        s_cnt = PLAYER_CLUB_SENIORS if is_player else LIGHT_SENIORS
        y_cnt = PLAYER_CLUB_YOUTH if is_player else LIGHT_YOUTH
        for _ in range(s_cnt):
            state.players.append(gen_player(rng, state, cid, club.country, is_youth=False))
        for _ in range(y_cnt):
            state.players.append(gen_player(rng, state, cid, club.country, is_youth=True))
        assist = gen_coach(rng, state, club.country)
        fit = gen_coach(rng, state, club.country)
        youth = gen_coach(rng, state, club.country)
        assist.role, fit.role, youth.role = "ASSIST", "FITNESS", "YOUTH"
        for c in [assist, fit, youth]:
            state.coaches[c.cid] = c
        club.coach_assist = assist.cid
        club.coach_fitness = fit.cid
        club.coach_youth = youth.cid
    refresh_markets(state, rng)
    return state


def topup_rosters_incremental(state: GameState, batch_clubs: int = 25) -> None:
    rng = _rng()
    clubs_need = []
    for cid, club in state.clubs.items():
        if cid == state.active_club_id:
            continue
        seniors = sum(1 for p in state.players if p.club_id == cid and not p.is_youth)
        youths = sum(1 for p in state.players if p.club_id == cid and p.is_youth)
        if seniors < OTHER_CLUB_SENIORS or youths < OTHER_CLUB_YOUTH:
            clubs_need.append(cid)
    for cid in clubs_need[:batch_clubs]:
        club = state.clubs[cid]
        seniors = [p for p in state.players if p.club_id == cid and not p.is_youth]
        youths = [p for p in state.players if p.club_id == cid and p.is_youth]
        while len(seniors) < OTHER_CLUB_SENIORS:
            p = gen_player(rng, state, cid, club.country, is_youth=False)
            state.players.append(p)
            seniors.append(p)
        while len(youths) < OTHER_CLUB_YOUTH:
            p = gen_player(rng, state, cid, club.country, is_youth=True)
            state.players.append(p)
            youths.append(p)


def refresh_markets(state: GameState, rng: random.Random) -> None:
    candidates = [p for p in state.players if p.club_id and p.club_id != state.active_club_id and not p.is_youth and p.injury_weeks == 0]
    rng.shuffle(candidates)
    state.transfer_market = [p.pid for p in candidates[:TRANSFER_MARKET_SIZE]]

    free_agents = [p for p in state.players if p.club_id == ""]
    while len(free_agents) < SCOUT_POOL_SIZE:
        ctry = rng.choice(COUNTRIES)
        p = gen_player(rng, state, "", ctry, is_youth=rng.random() < 0.5)
        p.scouted_level = 0
        state.players.append(p)
        free_agents.append(p)
    rng.shuffle(free_agents)
    state.scout_market = [p.pid for p in free_agents[:SCOUT_POOL_SIZE]]

    mgr_ids = []
    while len(mgr_ids) < STAFF_POOL_SIZE:
        ctry = rng.choice(COUNTRIES)
        m = gen_manager(rng, state, ctry)
        state.managers[m.mid] = m
        mgr_ids.append(m.mid)
    coach_ids = []
    while len(coach_ids) < STAFF_POOL_SIZE:
        ctry = rng.choice(COUNTRIES)
        c = gen_coach(rng, state, ctry)
        state.coaches[c.cid] = c
        coach_ids.append(c.cid)
    state.staff_market_managers = mgr_ids
    state.staff_market_coaches = coach_ids


def team_strength(state: GameState, cid: str) -> Dict[str, float]:
    club = state.clubs[cid]
    players = [p for p in state.players if p.club_id == cid and p.injury_weeks == 0]
    if not players:
        return {"atk": 40.0, "def": 40.0, "mid": 40.0}
    top = sorted(players, key=lambda p: p.overall, reverse=True)[:11]
    by_pos = {group: [p for p in top if p.pos == group] for group in POS_GROUPS}

    def avg(ps: List[Player]) -> float:
        return sum(p.overall for p in ps) / max(1, len(ps))

    atk = avg(by_pos["FW"]) * 1.1 + avg(by_pos["MF"]) * 0.5
    deff = avg(by_pos["DF"]) * 1.0 + avg(by_pos["GK"]) * 0.8 + avg(by_pos["MF"]) * 0.3
    mid = avg(by_pos["MF"]) * 1.2 + avg(by_pos["DF"]) * 0.2 + avg(by_pos["FW"]) * 0.2
    tac = TACTIC_PRESETS.get(club.tactic, TACTIC_PRESETS["BAL"])
    mgr = state.managers.get(club.manager_id)
    mgr_boost = (mgr.tactical / 100.0) if mgr else 0.6
    atk *= tac["atk"] * (0.9 + 0.2 * mgr_boost)
    deff *= tac["def"] * (0.9 + 0.2 * mgr_boost)
    mid *= tac["mid"] * (0.9 + 0.2 * mgr_boost)
    return {"atk": atk, "def": deff, "mid": mid}


def poisson_goals(rng: random.Random, lam: float) -> int:
    threshold = math.exp(-lam)
    k = 0
    p = 1.0
    while p > threshold and k < 10:
        k += 1
        p *= rng.random()
    return max(0, k - 1)


def play_match(state: GameState, home: str, away: str, rng: random.Random) -> Tuple[int, int]:
    hs = team_strength(state, home)
    aw = team_strength(state, away)
    base_h = 1.15 + (hs["atk"] - aw["def"]) / 60 + (hs["mid"] - aw["mid"]) / 120 + 0.22
    base_a = 0.95 + (aw["atk"] - hs["def"]) / 60 + (aw["mid"] - hs["mid"]) / 120
    lam_h = clamp(int(base_h * 100), 20, 360) / 100
    lam_a = clamp(int(base_a * 100), 15, 320) / 100
    return poisson_goals(rng, lam_h), poisson_goals(rng, lam_a)


def apply_result(table: Dict[str, Dict[str, int]], home: str, away: str, hg: int, ag: int) -> None:
    th = table[home]
    ta = table[away]
    th["gf"] += hg
    th["ga"] += ag
    ta["gf"] += ag
    ta["ga"] += hg
    if hg > ag:
        th["w"] += 1
        ta["l"] += 1
        th["pts"] += 3
    elif hg < ag:
        ta["w"] += 1
        th["l"] += 1
        ta["pts"] += 3
    else:
        th["d"] += 1
        ta["d"] += 1
        th["pts"] += 1
        ta["pts"] += 1


def rank_table(table: Dict[str, Dict[str, int]]) -> List[str]:
    return sorted(table.keys(), key=lambda tid: (table[tid]["pts"], table[tid]["gf"] - table[tid]["ga"], table[tid]["gf"]), reverse=True)


def progress_week(state: GameState) -> None:
    rng = _rng()
    for ctry in COUNTRIES:
        lg = state.leagues[ctry]
        idx = state.week - 1
        if idx < len(lg["fix1"]):
            for home, away in lg["fix1"][idx]:
                hg, ag = play_match(state, home, away, rng)
                apply_result(lg["table1"], home, away, hg, ag)
                state.match_log.append({"season": state.season, "week": state.week, "home": home, "away": away, "hg": hg, "ag": ag, "div": 1, "country": ctry})
        if idx < len(lg["fix2"]):
            for home, away in lg["fix2"][idx]:
                hg, ag = play_match(state, home, away, rng)
                apply_result(lg["table2"], home, away, hg, ag)
                state.match_log.append({"season": state.season, "week": state.week, "home": home, "away": away, "hg": hg, "ag": ag, "div": 2, "country": ctry})
    for p in state.players:
        if p.injury_weeks > 0:
            p.injury_weeks -= 1
        p.stamina = clamp(p.stamina + rng.randint(-3, 6), 45, 100)
        p.morale = clamp(p.morale + rng.randint(-2, 3), 30, 95)
        if p.club_id:
            gap = p.pot - p.overall
            if gap > 0:
                grow_chance = 0.12 if p.age <= 21 else 0.04 if p.age <= 27 else 0.01
                if rng.random() < grow_chance:
                    attr = rng.choice(ATTRS)
                    p.attrs[attr] = clamp(p.attrs[attr] + 1, 25, 99)
            elif p.age >= 31 and rng.random() < 0.05:
                attr = rng.choice(ATTRS)
                p.attrs[attr] = clamp(p.attrs[attr] - 1, 25, 99)
        if p.age >= p.retire_age and rng.random() < 0.03:
            p.club_id = ""
    for cid, club in state.clubs.items():
        club.budget += SPONSOR_WEEKLY
        club.budget -= compute_wages(state, cid)
    if state.week in TRANSFER_WINDOW_WEEKS:
        refresh_markets(state, rng)
    topup_rosters_incremental(state, batch_clubs=25)
    state.week += 1
    if state.week > WEEKS_PER_SEASON:
        state.week = 1
        state.season += 1
        for ctry in COUNTRIES:
            d1 = rank_table(state.leagues[ctry]["table1"])
            d2 = rank_table(state.leagues[ctry]["table2"])
            down = d1[-2:]
            up = d2[:2]
            for tid in up:
                state.clubs[tid].division = 1
            for tid in down:
                state.clubs[tid].division = 2
            new_d1 = [t for t in d1 if t not in down] + up
            new_d2 = [t for t in d2 if t not in up] + down
            rng.shuffle(new_d1)
            rng.shuffle(new_d2)
            state.leagues[ctry] = {
                "div1_ids": new_d1,
                "div2_ids": new_d2,
                "fix1": create_fixtures(new_d1, rng),
                "fix2": create_fixtures(new_d2, rng),
                "table1": init_table(new_d1),
                "table2": init_table(new_d2),
            }


def get_player(state: GameState, pid: int) -> Optional[Player]:
    return next((p for p in state.players if p.pid == pid), None)


def buy_player(state: GameState, pid: int) -> tuple[bool, str]:
    p = get_player(state, pid)
    if not p or pid not in state.transfer_market:
        return False, "Player not found in transfer market."
    if not p.club_id or p.club_id == state.active_club_id:
        return False, "Invalid source club."
    club = state.clubs[state.active_club_id]
    price = int((p.overall ** 2) * 1200)
    if club.budget < price:
        return False, "Budget too low."
    club.budget -= price
    state.clubs[p.club_id].budget += price
    p.club_id = state.active_club_id
    if pid in state.transfer_market:
        state.transfer_market.remove(pid)
    return True, f"Signed {p.name} for {price:,}"


def scout_visit(state: GameState, pid: int) -> tuple[bool, str]:
    p = get_player(state, pid)
    if not p or pid not in state.scout_market:
        return False, "Prospect not found."
    fee = 40_000 + p.age * 2_000
    club = state.clubs[state.active_club_id]
    if club.budget < fee:
        return False, "Budget too low."
    club.budget -= fee
    p.scouted_level = clamp(p.scouted_level + 1, 0, 3)
    fuzz = {1: 8, 2: 4, 3: 1}[p.scouted_level]
    p.est_overall = clamp(p.overall + random.randint(-fuzz, fuzz), 1, 99)
    p.est_pot = clamp(p.pot + random.randint(-fuzz, fuzz), 1, 99)
    return True, f"Scouted {p.name}. Level {p.scouted_level}"


def sign_scouted(state: GameState, pid: int) -> tuple[bool, str]:
    p = get_player(state, pid)
    if not p or pid not in state.scout_market:
        return False, "Prospect not found."
    if p.scouted_level <= 0:
        return False, "Scout the player first."
    club = state.clubs[state.active_club_id]
    price = int((max(42, p.est_overall or p.overall) ** 2) * 900)
    if club.budget < price:
        return False, "Budget too low."
    club.budget -= price
    p.club_id = state.active_club_id
    state.scout_market.remove(pid)
    return True, f"Signed prospect {p.name} for {price:,}"


def hire_manager(state: GameState, mid: int) -> tuple[bool, str]:
    if mid not in state.staff_market_managers or mid not in state.managers:
        return False, "Manager not found."
    club = state.clubs[state.active_club_id]
    manager = state.managers[mid]
    cost = manager.wage * 12
    if club.budget < cost:
        return False, "Budget too low."
    club.budget -= cost
    club.manager_id = mid
    return True, f"Hired manager {manager.name}"


def hire_coach(state: GameState, cid: int) -> tuple[bool, str]:
    if cid not in state.staff_market_coaches or cid not in state.coaches:
        return False, "Coach not found."
    club = state.clubs[state.active_club_id]
    coach = state.coaches[cid]
    cost = coach.wage * 10
    if club.budget < cost:
        return False, "Budget too low."
    club.budget -= cost
    if coach.role == "ASSIST":
        club.coach_assist = cid
    elif coach.role == "FITNESS":
        club.coach_fitness = cid
    else:
        club.coach_youth = cid
    return True, f"Hired coach {coach.name} ({coach.role})"


def serialize_state(state: GameState) -> Dict[str, Any]:
    return {
        "season": state.season,
        "week": state.week,
        "next_pid": state.next_pid,
        "next_mid": state.next_mid,
        "next_cid": state.next_cid,
        "active_country": state.active_country,
        "active_division": state.active_division,
        "active_club_id": state.active_club_id,
        "clubs": {k: asdict(v) for k, v in state.clubs.items()},
        "players": [asdict(p) for p in state.players],
        "managers": {str(k): asdict(v) for k, v in state.managers.items()},
        "coaches": {str(k): asdict(v) for k, v in state.coaches.items()},
        "leagues": state.leagues,
        "match_log": state.match_log,
        "transfer_market": state.transfer_market,
        "scout_market": state.scout_market,
        "staff_market_managers": state.staff_market_managers,
        "staff_market_coaches": state.staff_market_coaches,
    }


def deserialize_state(blob: Dict[str, Any]) -> GameState:
    state = GameState(
        season=blob["season"],
        week=blob["week"],
        next_pid=blob["next_pid"],
        next_mid=blob["next_mid"],
        next_cid=blob["next_cid"],
        active_country=blob["active_country"],
        active_division=blob["active_division"],
        active_club_id=blob["active_club_id"],
    )
    state.clubs = {k: Club(**v) for k, v in blob["clubs"].items()}
    state.players = [Player(**p) for p in blob["players"]]
    state.managers = {int(k): Manager(**v) for k, v in blob["managers"].items()}
    state.coaches = {int(k): Coach(**v) for k, v in blob["coaches"].items()}
    state.leagues = blob["leagues"]
    state.match_log = blob["match_log"]
    state.transfer_market = blob["transfer_market"]
    state.scout_market = blob["scout_market"]
    state.staff_market_managers = blob["staff_market_managers"]
    state.staff_market_coaches = blob["staff_market_coaches"]
    return state
