from __future__ import annotations

import pandas as pd
from nicegui import ui


def table_from_rows(rows: list[dict], columns: list[str], pagination: int = 10) -> None:
    if not rows:
        ui.label("No data.").classes("text-sm text-gray-400")
        return
    df = pd.DataFrame(rows)
    ui.table.from_pandas(df[columns], pagination=pagination).classes(
        "w-full text-sm"
    ).props('flat bordered dense wrap-cells')


def mobile_cards_from_rows(rows: list[dict], title_key: str | None = None, subtitle_keys: list[str] | None = None,
                           detail_keys: list[str] | None = None, max_items: int | None = None) -> None:
    if not rows:
        ui.label("No data.").classes("text-sm text-gray-400")
        return
    subtitle_keys = subtitle_keys or []
    detail_keys = detail_keys or []
    target_rows = rows[:max_items] if max_items else rows
    with ui.column().classes('w-full gap-2 md:hidden'):
        for row in target_rows:
            title = str(row.get(title_key, '')) if title_key else ''
            subtitles = [str(row.get(k, '')) for k in subtitle_keys if row.get(k, '') not in ('', None)]
            with ui.card().classes('w-full p-3 gap-2 rounded-xl shadow-sm'):
                if title:
                    ui.label(title).classes('text-base font-semibold leading-tight')
                if subtitles:
                    ui.label(' • '.join(subtitles)).classes('text-xs text-gray-500')
                if detail_keys:
                    with ui.grid(columns=2).classes('w-full gap-x-3 gap-y-1'):
                        for key in detail_keys:
                            value = row.get(key, '-')
                            ui.label(key).classes('text-[11px] uppercase tracking-wide text-gray-400')
                            ui.label(str(value)).classes('text-sm text-right font-medium')


def responsive_rows(rows: list[dict], columns: list[str], *, title_key: str | None = None,
                    subtitle_keys: list[str] | None = None, detail_keys: list[str] | None = None,
                    pagination: int = 10, max_mobile_items: int | None = None) -> None:
    if not rows:
        ui.label("No data.").classes("text-sm text-gray-400")
        return
    with ui.element('div').classes('hidden md:block w-full'):
        table_from_rows(rows, columns, pagination=pagination)
    mobile_cards_from_rows(rows, title_key=title_key, subtitle_keys=subtitle_keys,
                           detail_keys=detail_keys, max_items=max_mobile_items)


def stat_chip(label: str, value: str) -> None:
    with ui.card().classes('min-w-[140px] flex-1 p-3 rounded-xl bg-slate-50 shadow-sm'):
        ui.label(label).classes('text-xs uppercase tracking-wide text-gray-400')
        ui.label(str(value)).classes('text-lg font-bold leading-tight')


def notify_result(ok: bool, msg: str) -> None:
    ui.notify(msg, color="positive" if ok else "negative")
