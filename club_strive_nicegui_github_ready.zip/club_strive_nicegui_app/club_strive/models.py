from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .config import ATTRS


@dataclass
class Player:
    pid: int
    name: str
    age: int
    nationality: str
    pos: str
    club_id: str
    is_youth: bool
    retire_age: int
    attrs: Dict[str, int]
    pot: int
    morale: int = 60
    stamina: int = 90
    injury_weeks: int = 0
    scouted_level: int = 0
    est_overall: int = 0
    est_pot: int = 0

    @property
    def overall(self) -> int:
        weights = {
            "GK": {"DEF": 0.35, "PHY": 0.20, "MEN": 0.20, "PAS": 0.10, "TEC": 0.05, "SPD": 0.05, "SHT": 0.05},
            "DF": {"DEF": 0.30, "PHY": 0.20, "SPD": 0.10, "PAS": 0.10, "TEC": 0.10, "MEN": 0.15, "SHT": 0.05},
            "MF": {"PAS": 0.20, "TEC": 0.20, "MEN": 0.15, "SPD": 0.10, "DEF": 0.10, "PHY": 0.10, "SHT": 0.15},
            "FW": {"SHT": 0.25, "TEC": 0.20, "SPD": 0.15, "MEN": 0.15, "PAS": 0.10, "PHY": 0.10, "DEF": 0.05},
        }[self.pos]
        return int(round(sum(self.attrs[a] * weights[a] for a in ATTRS)))


@dataclass
class Manager:
    mid: int
    name: str
    age: int
    nationality: str
    retire_age: int
    preferred_tactic: str
    preferred_formation: str
    tactical: int
    man_mgmt: int
    youth_dev: int
    transfer_skill: int
    discipline: int
    wage: int
    contract_years: int


@dataclass
class Coach:
    cid: int
    name: str
    age: int
    nationality: str
    role: str
    tactical: int
    fitness: int
    youth: int
    wage: int
    contract_years: int


@dataclass
class Club:
    club_id: str
    name: str
    country: str
    division: int
    budget: int
    reputation: int
    manager_id: int
    tactic: str = "BAL"
    formation: str = "442"
    coach_assist: Optional[int] = None
    coach_fitness: Optional[int] = None
    coach_youth: Optional[int] = None


@dataclass
class GameState:
    season: int = 1
    week: int = 1
    next_pid: int = 1
    next_mid: int = 1
    next_cid: int = 1
    active_country: str = "日本"
    active_division: int = 1
    active_club_id: str = ""
    clubs: Dict[str, Club] = field(default_factory=dict)
    players: List[Player] = field(default_factory=list)
    managers: Dict[int, Manager] = field(default_factory=dict)
    coaches: Dict[int, Coach] = field(default_factory=dict)
    leagues: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    match_log: List[Dict[str, Any]] = field(default_factory=list)
    transfer_market: List[int] = field(default_factory=list)
    scout_market: List[int] = field(default_factory=list)
    staff_market_managers: List[int] = field(default_factory=list)
    staff_market_coaches: List[int] = field(default_factory=list)
