from __future__ import annotations

from typing import Optional

from nicegui import app

from .config import I18N
from .models import GameState


def store() -> dict:
    return app.storage.user


def ensure_defaults() -> None:
    s = store()
    s.setdefault("lang", "ja")
    s.setdefault("player_name", "Player")
    s.setdefault("tick", 0)
    s.setdefault("state_blob", None)
    s.setdefault("used_names", set())


def L(key: str) -> str:
    lang = store().get("lang", "ja")
    return I18N.get(key, {}).get(lang, key)


def save_state_blob(blob: dict | None) -> None:
    store()["state_blob"] = blob
