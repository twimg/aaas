from __future__ import annotations

from typing import Optional

from .logic import deserialize_state, serialize_state
from .models import GameState
from .storage import store


def save_state(state: Optional[GameState]) -> None:
    s = store()
    s["state_blob"] = serialize_state(state) if state else None


def load_state() -> Optional[GameState]:
    blob = store().get("state_blob")
    return deserialize_state(blob) if blob else None
