# Club Strive NiceGUI 再構成版

Streamlit単一ファイルを、NiceGUI向けに再構成した版です。  
GitHubへそのまま上げて、Renderなどにデプロイしやすい形にしてあります。

## 構成
- `club_strive/config.py` 設定値・定数・i18n
- `club_strive/models.py` データモデル
- `club_strive/storage.py` NiceGUIのユーザーストレージまわり
- `club_strive/logic.py` ゲームロジック
- `club_strive/persistence.py` セーブ/ロード
- `club_strive/ui_helpers.py` 表示補助
- `club_strive/views.py` 画面描画
- `main.py` 起動ポイント
- `requirements.txt` 依存関係

## ローカル起動
```bash
pip install -r requirements.txt
python main.py
```

## GitHubへ上げる手順
1. このフォルダ一式をGitHubリポジトリへアップロード
2. `requirements.txt` と `main.py` がルートにあることを確認
3. Render / Railway などで新しい Python Web Service として接続

## Renderの設定例
- **Build Command**
```bash
pip install -r requirements.txt
```
- **Start Command**
```bash
python main.py
```

## 公開向け設定
`main.py` は以下を自動対応済みです。
- `host='0.0.0.0'`
- `port=os.getenv('PORT', 8080)`

そのため、Renderなどの環境変数 `PORT` にそのまま対応します。

## 注意
この段階では「再構成して今後育てやすくした版」です。UI/ロジック分離はかなり改善していますが、
本格的にアプリ化するなら、次に `views.py` をページ単位でさらに分割した方がいいです。
